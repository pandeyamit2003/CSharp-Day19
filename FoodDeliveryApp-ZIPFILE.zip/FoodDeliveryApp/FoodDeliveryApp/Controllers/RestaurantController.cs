﻿using Microsoft.AspNetCore.Mvc;

namespace FoodDeliveryApp.Controllers
{
    public class RestaurantController : Controller
    {
        // Menu Page
        public IActionResult Menu()
        {
            return Content("Restaurant Menu Page");
        }

        // Details Page
        public IActionResult Details(int id)
        {
            return Content("Restaurant Details ID: " + id);
        }
    }
}